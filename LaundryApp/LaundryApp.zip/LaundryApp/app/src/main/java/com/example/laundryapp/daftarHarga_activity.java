package com.example.laundryapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class daftarHarga_activity extends AppCompatActivity {

    private Button buttonmulai,buttonHistory;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daftar_harga);

        buttonmulai = findViewById(R.id.buttonmulai);
        buttonmulai.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Arahkan ke activity lain
                Intent intent = new Intent(daftarHarga_activity.this,MainActivity.class);
                startActivity(intent);
            }

        });
        buttonHistory = findViewById(R.id.buttonHistory);
        buttonHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(daftarHarga_activity.this, HistoryActivity.class);
                startActivity(intent);
            }
        });
    }


}
