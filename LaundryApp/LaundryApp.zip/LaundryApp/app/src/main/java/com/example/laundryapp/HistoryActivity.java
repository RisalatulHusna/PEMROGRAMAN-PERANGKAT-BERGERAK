package com.example.laundryapp;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class HistoryActivity extends AppCompatActivity {

    private ListView listViewHistory;
    private ArrayAdapter<String> historyAdapter;
    private ArrayList<String> historyList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        listViewHistory = findViewById(R.id.listViewHistory);
        historyList = new ArrayList<>();

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String nama = extras.getString("nama");
            String alamat = extras.getString("alamat");
            String noTelpon = extras.getString("noTelpon");
            String jenisLaundry = extras.getString("jenisLaundry");
            int jumlahKilo = extras.getInt("jumlahKilo");

            String history = "Nama: " + nama +
                    "\nAlamat: " + alamat +
                    "\nNo. Telpon: " + noTelpon +
                    "\nJenis Laundry: " + jenisLaundry +
                    "\nJumlah Kilo: " + jumlahKilo;

            historyList.add(history);
        }

        historyAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, historyList);
        listViewHistory.setAdapter(historyAdapter);
    }
}
